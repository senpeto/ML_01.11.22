
#include "stm32f4xx.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_exti.h"
#include "misc.h"

void InitButt(void) {
	  GPIO_InitTypeDef gpioConf;
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	  gpioConf.GPIO_Pin = GPIO_Pin_0;
	  gpioConf.GPIO_Mode = GPIO_Mode_IN;
	  gpioConf.GPIO_PuPd = GPIO_PuPd_NOPULL;
	  GPIO_Init(GPIOA, &gpioConf);

	  EXTI_InitTypeDef extiConf;
	  extiConf.EXTI_Line = EXTI_Line0;
	  extiConf.EXTI_Mode = EXTI_Mode_Interrupt;
	  extiConf.EXTI_Trigger = EXTI_Trigger_Rising;
	  extiConf.EXTI_LineCmd = ENABLE;
	  EXTI_Init(&extiConf);


	  NVIC_InitTypeDef nvicConf;
	  nvicConf.NVIC_IRQChannel = EXTI0_IRQn;
	  nvicConf.NVIC_IRQChannelPreemptionPriority = 0x00;
	  nvicConf.NVIC_IRQChannelSubPriority = 0x00;
	  nvicConf.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&nvicConf);
}

void InitLED(void) {
	  GPIO_InitTypeDef gpioConf;
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	  gpioConf.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	  gpioConf.GPIO_Mode = GPIO_Mode_OUT;
	  gpioConf.GPIO_Speed = GPIO_Speed_100MHz;
	  gpioConf.GPIO_OType = GPIO_OType_PP;
	  GPIO_Init(GPIOD, &gpioConf);
}


void ButtStatus(void) {
	while (EXTI_GetITStatus(EXTI_Line0) != RESET) {
		GPIO_SetBits(GPIOD, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15);
		EXTI_ClearITPendingBit(EXTI_Line0);
	}
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0) {
		GPIO_ResetBits(GPIOD, GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15);
	}
}
